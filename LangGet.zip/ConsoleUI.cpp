﻿#include "LangGet.h"

// 控制台颜色定义（LangGet.h中已声明，此处无需重复）
// COLOR_INFO=7, COLOR_SUCCESS=10, COLOR_ERROR=12

// 设置控制台颜色
void SetConsoleColor(int color) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, color);
}

// 打印进度条（修复float转int警告+格式错误）
void PrintProgressBar(DWORD downloaded, DWORD total, double speed) {
    const int barWidth = 10;
    float progress = (float)downloaded / total;
    int pos = static_cast<int>(barWidth * progress); // 显式转换消除警告

    SetConsoleColor(COLOR_INFO);
    _tprintf(_T("\r[+] 下载中 "));
    for (int i = 0; i < barWidth; i++) {
        if (i < pos) _tprintf(_T("█"));
        else _tprintf(_T(" "));
    }
    _tprintf(_T(" %d%% %.1lfMB/s"), static_cast<int>(progress * 100), speed / 1024 / 1024);
    fflush(stdout);

    // 进度100%时换行
    if (progress >= 1.0) {
        _tprintf(_T("\n"));
    }
}

// 通用日志打印（修复宏扩展错误）
void Log(const TCHAR* format, ...) {
    SetConsoleColor(COLOR_INFO);
    va_list args;
    va_start(args, format);
    _vtprintf(format, args);
    va_end(args);
    _tprintf(_T("\n"));
    SetConsoleColor(COLOR_INFO); // 恢复默认颜色
}

// 成功日志
void LogSuccess(const TCHAR* format, ...) {
    SetConsoleColor(COLOR_SUCCESS);
    va_list args;
    va_start(args, format);
    _vtprintf(format, args);
    va_end(args);
    _tprintf(_T("\n"));
    SetConsoleColor(COLOR_INFO);
}

// 错误日志
void LogError(const TCHAR* format, ...) {
    SetConsoleColor(COLOR_ERROR);
    va_list args;
    va_start(args, format);
    _vtprintf(format, args);
    va_end(args);
    _tprintf(_T("\n"));
    SetConsoleColor(COLOR_INFO);
}