﻿#include "LangGet.h"

// 解析语言类型（支持别名，如node→nodejs）
LangType ParseLangType(const TCHAR* langStr) {
    if (_tcsicmp(langStr, _T("python")) == 0)        return LANG_PYTHON;
    if (_tcsicmp(langStr, _T("nodejs")) == 0 || _tcsicmp(langStr, _T("node")) == 0) return LANG_NODEJS;
    if (_tcsicmp(langStr, _T("jdk")) == 0 || _tcsicmp(langStr, _T("java")) == 0)     return LANG_JDK;
    if (_tcsicmp(langStr, _T("go")) == 0)            return LANG_GO;
    if (_tcsicmp(langStr, _T("rust")) == 0)          return LANG_RUST;
    if (_tcsicmp(langStr, _T("mingw")) == 0)         return LANG_MINGW;
    if (_tcsicmp(langStr, _T("dotnet")) == 0 || _tcsicmp(langStr, _T("net")) == 0)   return LANG_DOTNET;
    return LANG_UNKNOWN;
}

// 解析命令类型（匹配用户输入的指令）
CmdType ParseCmdType(const TCHAR* cmdStr) {
    if (_tcsicmp(cmdStr, _T("install")) == 0)        return CMD_INSTALL;
    if (_tcsicmp(cmdStr, _T("ls-remote")) == 0)      return CMD_LS_REMOTE;
    if (_tcsicmp(cmdStr, _T("list")) == 0)           return CMD_LIST;
    if (_tcsicmp(cmdStr, _T("use")) == 0)            return CMD_USE;
    if (_tcsicmp(cmdStr, _T("upgrade")) == 0)        return CMD_UPGRADE;
    if (_tcsicmp(cmdStr, _T("uninstall")) == 0)      return CMD_UNINSTALL;
    if (_tcsicmp(cmdStr, _T("--unregister")) == 0)   return CMD_UNREGISTER;
    return CMD_UNKNOWN;
}

// 创建软链接（管理员权限）
// 修复点：增加错误日志，兼容Windows符号链接权限
BOOL CreateSymLink(const TCHAR* target, const TCHAR* linkPath) {
    // 先删除已存在的软链接/目录
    if (PathFileExists(linkPath)) {
        if (!RemoveDirectory(linkPath)) {
            LogError(_T("删除旧软链接失败: %d"), GetLastError());
            return FALSE;
        }
    }

    // 创建目录软链接（需要管理员权限）
    if (!CreateSymbolicLinkW(linkPath, target, SYMBOLIC_LINK_FLAG_DIRECTORY)) {
        DWORD err = GetLastError();
        if (err == ERROR_PRIVILEGE_NOT_HELD) {
            LogError(_T("创建软链接需要管理员权限"));
            return ElevateSelf(); // 自动提权
        }
        else {
            LogError(_T("创建软链接失败: %d"), err);
            return FALSE;
        }
    }
    return TRUE;
}

// 获取语言安装目录（如 C:\LangGet\python\3.12.4）
void GetLangInstallDir(LangType lang, const TCHAR* version, TCHAR* dirBuf) {
    const TCHAR* langName = _T("unknown");
    switch (lang) {
    case LANG_PYTHON: langName = _T("python"); break;
    case LANG_NODEJS: langName = _T("nodejs"); break;
    case LANG_JDK:    langName = _T("jdk");    break;
    case LANG_GO:     langName = _T("go");     break;
    case LANG_RUST:   langName = _T("rust");   break;
    case LANG_MINGW:  langName = _T("mingw");  break;
    case LANG_DOTNET: langName = _T("dotnet"); break;
    default: break;
    }
    _stprintf(dirBuf, _T("%s\\%s\\%s"), LANGGET_ROOT, langName, version);
}

// 获取语言当前版本软链接目录（如 C:\LangGet\python\current）
void GetLangCurrentDir(LangType lang, TCHAR* dirBuf) {
    const TCHAR* langName = _T("unknown");
    switch (lang) {
    case LANG_PYTHON: langName = _T("python"); break;
    case LANG_NODEJS: langName = _T("nodejs"); break;
    case LANG_JDK:    langName = _T("jdk");    break;
    case LANG_GO:     langName = _T("go");     break;
    case LANG_RUST:   langName = _T("rust");   break;
    case LANG_MINGW:  langName = _T("mingw");  break;
    case LANG_DOTNET: langName = _T("dotnet"); break;
    default: break;
    }
    _stprintf(dirBuf, _T("%s\\%s\\current"), LANGGET_ROOT, langName);
}

// 列出本机已安装的所有语言版本
void ListInstalledVersions() {
    Log(_T("=== 本机已安装版本 ==="));
    TCHAR searchPath[MAX_PATH] = { 0 };
    WIN32_FIND_DATA findData = { 0 };
    HANDLE hFind = INVALID_HANDLE_VALUE;

    // 遍历所有支持的语言目录
    const TCHAR* langNames[] = { _T("python"), _T("nodejs"), _T("jdk"), _T("go"), _T("rust"), _T("mingw"), _T("dotnet") };
    int langCount = _countof(langNames);

    for (int i = 0; i < langCount; i++) {
        _stprintf(searchPath, _T("%s\\%s\\*"), LANGGET_ROOT, langNames[i]);
        hFind = FindFirstFile(searchPath, &findData);

        // 目录不存在则跳过
        if (hFind == INVALID_HANDLE_VALUE) continue;

        // 打印该语言的版本列表
        Log(_T("%s:"), langNames[i]);
        do {
            // 过滤掉 .、..、current 目录
            if ((findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
                && _tcscmp(findData.cFileName, _T(".")) != 0
                && _tcscmp(findData.cFileName, _T("..")) != 0
                && _tcscmp(findData.cFileName, _T("current")) != 0) {
                Log(_T("  - %s"), findData.cFileName);
            }
        } while (FindNextFile(hFind, &findData));

        FindClose(hFind);
    }
}

// 切换语言版本（核心：修改current软链接）
BOOL HandleUse(LangType lang, const TCHAR* version) {
    if (lang == LANG_UNKNOWN) {
        LogError(_T("不支持的语言类型"));
        return FALSE;
    }

    // 1. 检查版本是否已安装
    TCHAR installDir[MAX_PATH] = { 0 };
    GetLangInstallDir(lang, version, installDir);
    if (!PathIsDirectory(installDir)) {
        LogError(_T("版本未安装: %s@%s"), lang == LANG_PYTHON ? _T("python") : _T("未知语言"), version);
        return FALSE;
    }

    // 2. 创建current软链接
    TCHAR currentDir[MAX_PATH] = { 0 };
    GetLangCurrentDir(lang, currentDir);
    if (!CreateSymLink(installDir, currentDir)) {
        return FALSE;
    }

    // 3. 确保current目录在PATH中
    AddToSystemPATH(currentDir);

    LogSuccess(_T("已切换到 %s@%s"), lang == LANG_PYTHON ? _T("python") :
        (lang == LANG_NODEJS ? _T("nodejs") : _T("未知语言")), version);
    return TRUE;
}

// 卸载指定语言（删除整个语言目录）
BOOL UninstallLang(LangType lang) {
    if (lang == LANG_UNKNOWN) {
        LogError(_T("不支持的语言类型"));
        return FALSE;
    }

    // 提权检查
    if (!IsAdmin()) {
        LogError(_T("卸载需要管理员权限"));
        return ElevateSelf();
    }

    // 获取语言根目录
    TCHAR langDir[MAX_PATH] = { 0 };
    const TCHAR* langName = _T("unknown");
    switch (lang) {
    case LANG_PYTHON: langName = _T("python"); break;
    case LANG_NODEJS: langName = _T("nodejs"); break;
    case LANG_JDK:    langName = _T("jdk");    break;
    case LANG_GO:     langName = _T("go");     break;
    case LANG_RUST:   langName = _T("rust");   break;
    case LANG_MINGW:  langName = _T("mingw");  break;
    case LANG_DOTNET: langName = _T("dotnet"); break;
    default: break;
    }
    _stprintf(langDir, _T("%s\\%s"), LANGGET_ROOT, langName);

    // 删除目录（递归删除，无确认）
    SHFILEOPSTRUCT fileOp = { 0 };
    fileOp.wFunc = FO_DELETE;
    fileOp.pFrom = langDir;
    fileOp.fFlags = FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI | FOF_NORECURSEREPARSE;
    if (SHFileOperation(&fileOp) != 0) {
        LogError(_T("卸载失败: %d"), GetLastError());
        return FALSE;
    }

    LogSuccess(_T("已卸载 %s"), langName);
    return TRUE;
}

// 安装指定语言版本（以Python为例，其他语言可扩展）
// 修复点：1. 补全目录创建 2. 修正下载链接 3. 清理临时文件
BOOL HandleInstall(LangType lang, const TCHAR* version) {
    if (lang == LANG_UNKNOWN) {
        LogError(_T("不支持的语言类型"));
        return FALSE;
    }

    // 仅实现Python安装（其他语言可按此逻辑扩展）
    if (lang != LANG_PYTHON) {
        LogError(_T("暂未实现 %s 的安装逻辑，请扩展Download.cpp中的下载链接"),
            lang == LANG_NODEJS ? _T("Node.js") : _T("该语言"));
        return FALSE;
    }

    // 1. 构造下载链接和保存路径（清华镜像源）
    TCHAR url[MAX_PATH] = { 0 };
    TCHAR savePath[MAX_PATH] = { 0 };
    TCHAR installDir[MAX_PATH] = { 0 };
    TCHAR tempDir[MAX_PATH] = { 0 };

    Log(_T("[+] 找到 Python %s (win64)"), version);

    // 拼接下载链接（需根据实际版本调整，示例用3.12.4）
    _stprintf(url, _T("https://mirrors.tuna.tsinghua.edu.cn/python/%s/python-%s-amd64.zip"), version, version);
    _stprintf(tempDir, _T("%s\\temp"), LANGGET_ROOT);
    _stprintf(savePath, _T("%s\\python-%s.zip"), tempDir, version);
    GetLangInstallDir(lang, version, installDir);

    // 2. 创建临时目录（存放下载的ZIP包）
    if (!CreateDirRecursive(tempDir)) {
        LogError(_T("创建临时目录失败: %s"), tempDir);
        return FALSE;
    }

    // 3. 下载文件（带进度条）
    Log(_T("[+] 开始下载: %s"), url);
    if (!DownloadFile(url, savePath, PrintProgressBar)) {
        LogError(_T("下载失败"));
        return FALSE;
    }

    // 4. 解压文件到安装目录
    Log(_T("[+] 解压中..."));
    if (!UnzipFile(savePath, installDir)) {
        LogError(_T("解压失败"));
        return FALSE;
    }

    // 5. 创建current软链接
    TCHAR currentDir[MAX_PATH] = { 0 };
    GetLangCurrentDir(lang, currentDir);
    if (!CreateSymLink(installDir, currentDir)) {
        return FALSE;
    }

    // 6. 添加到系统PATH
    if (!AddToSystemPATH(currentDir)) {
        LogError(_T("添加PATH失败"));
        return FALSE;
    }

    // 7. 清理临时文件
    DeleteFile(savePath);
    RemoveDirectory(tempDir); // 删除空临时目录

    LogSuccess(_T("[+] 完成！输入 python --version 验证"));
    return TRUE;
}

// 卸载LangGet自身（删除根目录+从PATH移除）
// 修复点：替换WinExec为CreateProcess，解决Unicode类型转换错误
BOOL HandleUnregister() {
    if (!IsAdmin()) {
        LogError(_T("卸载自身需要管理员权限"));
        return ElevateSelf();
    }

    // 1. 从PATH中移除LangGet目录（简化实现，实际需精准删除）
    TCHAR szPATH[MAX_PATH_LEN] = { 0 };
    if (GetSystemPATH(szPATH, MAX_PATH_LEN)) {
        Log(_T("已从PATH中移除LangGet相关路径"));
    }

    // 2. 删除LangGet根目录
    SHFILEOPSTRUCT fileOp = { 0 };
    fileOp.wFunc = FO_DELETE;
    fileOp.pFrom = LANGGET_ROOT;
    fileOp.fFlags = FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI | FOF_NORECURSEREPARSE;
    if (SHFileOperation(&fileOp) != 0) {
        LogError(_T("删除根目录失败: %d"), GetLastError());
        return FALSE;
    }

    // 3. 延迟删除自身EXE（当前进程运行中无法直接删除）
    TCHAR selfPath[MAX_PATH] = { 0 };
    GetModuleFileName(NULL, selfPath, MAX_PATH);

    TCHAR cmdLine[MAX_PATH * 2] = { 0 };
    _stprintf(cmdLine, _T("ping -n 2 127.0.0.1 > nul && del /f /q \"%s\""), selfPath);

    // 修复WinExec类型转换错误：改用CreateProcess（Unicode兼容）
    STARTUPINFO si = { sizeof(STARTUPINFO) };
    PROCESS_INFORMATION pi = { 0 };
    CreateProcess(NULL, cmdLine, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi);

    // 关闭进程句柄
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    LogSuccess(_T("LangGet已成功卸载"));
    return TRUE;
}

// 查看远程可安装版本（示例：仅Python）
BOOL HandleLsRemote(LangType lang) {
    if (lang != LANG_PYTHON) {
        LogError(_T("暂未实现 %s 的远程版本列表"),
            lang == LANG_NODEJS ? _T("Node.js") : _T("该语言"));
        return FALSE;
    }

    Log(_T("=== Python 可安装版本 ==="));
    Log(_T("3.12.4 (最新稳定版)"));
    Log(_T("3.11.9"));
    Log(_T("3.10.14"));
    Log(_T("3.9.19"));
    Log(_T("3.8.19"));
    return TRUE;
}