﻿#include "LangGet.h"

// 仅保留EnvVar相关的辅助函数（删除重复的Add/GetSystemPATH）
// 检查环境变量是否存在
BOOL CheckEnvVarExists(const TCHAR* name) {
    TCHAR buf[1] = { 0 };
    DWORD ret = GetEnvironmentVariable(name, buf, 1);
    return ret > 0;
}

// 设置临时环境变量（当前进程有效）
BOOL SetTempEnvVar(const TCHAR* name, const TCHAR* value) {
    return SetEnvironmentVariable(name, value);
}