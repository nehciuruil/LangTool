﻿#include "LangGet.h"
#include "minizip/unzip.h"
#include "minizip/ioapi.h"

// 辅助函数：将TCHAR（Unicode）转换为char（多字节）
static void TCHARToChar(const TCHAR* tstr, char* cstr, int cstrLen) {
    if (tstr == NULL || cstr == NULL || cstrLen <= 0) return;
    // 宽字符转多字节（CP_ACP=系统默认编码）
    WideCharToMultiByte(CP_ACP, 0, tstr, -1, cstr, cstrLen, NULL, NULL);
    // 确保字符串以\0结尾
    cstr[cstrLen - 1] = '\0';
}

// 辅助函数：将char（多字节）转换为TCHAR（Unicode）
static void CharToTCHAR(const char* cstr, TCHAR* tstr, int tstrLen) {
    if (cstr == NULL || tstr == NULL || tstrLen <= 0) return;
    // 多字节转宽字符
    MultiByteToWideChar(CP_ACP, 0, cstr, -1, tstr, tstrLen);
    // 确保字符串以\0结尾
    tstr[tstrLen - 1] = _T('\0');
}

// 递归创建目录（修复C3861，与声明完全匹配）
BOOL CreateDirRecursive(const TCHAR* dir) {
    TCHAR temp[MAX_PATH] = { 0 };
    _tcscpy_s(temp, MAX_PATH, dir); // 用_s安全函数，避免缓冲区溢出

    // 遍历路径，逐级创建
    for (int i = 0; temp[i] != _T('\0'); i++) {
        if (temp[i] == _T('\\') || temp[i] == _T('/')) {
            temp[i] = _T('\0');
            // 跳过根目录（如C:\）
            if (_tcslen(temp) > 3) {
                if (!CreateDirectory(temp, NULL) && GetLastError() != ERROR_ALREADY_EXISTS) {
                    LogError(_T("创建目录失败: %s (错误码: %d)"), temp, GetLastError());
                    return FALSE;
                }
            }
            temp[i] = _T('\\');
        }
    }

    // 创建最后一级目录
    if (!CreateDirectory(dir, NULL) && GetLastError() != ERROR_ALREADY_EXISTS) {
        LogError(_T("创建目录失败: %s (错误码: %d)"), dir, GetLastError());
        return FALSE;
    }
    return TRUE;
}

// 解压ZIP文件到指定目录（核心修复类型转换）
BOOL UnzipFile(const TCHAR* zipPath, const TCHAR* destDir) {
    unzFile zipFile = NULL;
    unz_global_info zipInfo = { 0 };
    unz_file_info fileInfo = { 0 };

    // ========== 修复点1：char数组接收minizip的字符串 ==========
    char fileName_ansi[MAX_PATH] = { 0 };  // 多字节数组（适配minizip）
    TCHAR fileName[MAX_PATH] = { 0 };      // Unicode数组（项目使用）
    TCHAR fullPath[MAX_PATH] = { 0 };
    FILE* fp = NULL;
    BYTE buffer[BUFFER_SIZE] = { 0 };
    DWORD bytesRead = 0;

    // 1. 创建目标目录
    if (!CreateDirRecursive(destDir)) {
        return FALSE;
    }

    // ========== 修复点2：TCHAR转char，适配unzOpen ==========
    char zipPath_ansi[MAX_PATH] = { 0 };
    TCHARToChar(zipPath, zipPath_ansi, MAX_PATH);
    zipFile = unzOpen(zipPath_ansi); // 现在参数类型匹配
    if (zipFile == NULL) {
        LogError(_T("打开ZIP文件失败: %s"), zipPath);
        return FALSE;
    }

    // 3. 获取ZIP文件信息
    if (unzGetGlobalInfo(zipFile, &zipInfo) != UNZ_OK) {
        LogError(_T("获取ZIP信息失败"));
        goto Cleanup;
    }

    // 4. 遍历所有文件/目录
    for (uLong i = 0; i < zipInfo.number_entry; i++) {
        // ========== 修复点3：适配unzGetCurrentFileInfo的char*参数 ==========
        memset(fileName_ansi, 0, MAX_PATH); // 清空多字节数组
        if (unzGetCurrentFileInfo(
            zipFile,
            &fileInfo,
            fileName_ansi,       // char* 参数（适配minizip）
            MAX_PATH,            // 长度（uLong）
            NULL, 0, NULL, 0) != UNZ_OK) {
            LogError(_T("获取文件信息失败"));
            goto Cleanup;
        }

        // 多字节转Unicode，供项目使用
        CharToTCHAR(fileName_ansi, fileName, MAX_PATH);

        // 拼接完整路径
        _stprintf_s(fullPath, MAX_PATH, _T("%s\\%s"), destDir, fileName);

        // 判断是否为目录
        if (fileName[_tcslen(fileName) - 1] == _T('/') || fileName[_tcslen(fileName) - 1] == _T('\\')) {
            CreateDirRecursive(fullPath);
        }
        else {
            // 打开ZIP内的文件
            if (unzOpenCurrentFile(zipFile) != UNZ_OK) {
                LogError(_T("打开ZIP内文件失败: %s"), fileName);
                goto Cleanup;
            }

            // 创建文件（覆盖已存在）
            errno_t err = _tfopen_s(&fp, fullPath, _T("wb"));
            if (err != 0 || fp == NULL) {
                LogError(_T("创建文件失败: %s"), fullPath);
                unzCloseCurrentFile(zipFile);
                goto Cleanup;
            }

            // 读取并写入文件
            while (true) {
                bytesRead = unzReadCurrentFile(zipFile, buffer, BUFFER_SIZE);
                if (bytesRead < 0) {
                    LogError(_T("读取ZIP文件失败: %s"), fileName);
                    fclose(fp);
                    unzCloseCurrentFile(zipFile);
                    goto Cleanup;
                }
                if (bytesRead == 0) break; // 读取完毕
                fwrite(buffer, 1, bytesRead, fp);
            }

            // 关闭文件
            fclose(fp);
            unzCloseCurrentFile(zipFile);
        }

        // 移动到下一个文件
        if (i < zipInfo.number_entry - 1) {
            unzGoToNextFile(zipFile);
        }
    }

    LogSuccess(_T("解压完成: %s"), destDir);
    unzClose(zipFile);
    return TRUE;

Cleanup:
    if (zipFile != NULL) unzClose(zipFile);
    if (fp != NULL) fclose(fp);
    return FALSE;
}