﻿#pragma once
#include <windows.h>
#include <winhttp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <shlwapi.h>
#include <tchar.h>
#include <aclapi.h>
#include <stdarg.h> // 新增：va_list需要的头文件
#include <shlobj.h> // 新增：SHFileOperation需要的头文件
#include <atlconv.h> // 新增：CT2A转换需要的头文件

// 新增：WinHTTP回调标志定义（如果SDK版本低，手动定义）
#ifndef WINHTTP_CALLBACK_FLAG_STATUS_ALL_COMPLETIONS
#define WINHTTP_CALLBACK_FLAG_STATUS_ALL_COMPLETIONS 0x000000FF
#endif
#ifndef INTERNET_STATUS_CONTENT_LENGTH_RECEIVED
#define INTERNET_STATUS_CONTENT_LENGTH_RECEIVED 0x00000200
#endif
#ifndef INTERNET_STATUS_DATA_RECEIVED
#define INTERNET_STATUS_DATA_RECEIVED 0x00000202
#endif

// 链接必要的系统库
#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "shlwapi.lib")
#pragma comment(lib, "advapi32.lib")
#pragma comment(lib, "shell32.lib") // 新增：SHFileOperation需要的库



// 全局配置
#define LANGGET_ROOT _T("C:\\LangGet")
#define BUFFER_SIZE 4096
#define MAX_PATH_LEN 32767

// 控制台颜色定义
#define COLOR_INFO    7       // 白色（默认）
#define COLOR_SUCCESS 10      // 绿色
#define COLOR_ERROR   12      // 红色

// 支持的语言类型
typedef enum {
    LANG_PYTHON,
    LANG_NODEJS,
    LANG_JDK,
    LANG_GO,
    LANG_RUST,
    LANG_MINGW,
    LANG_DOTNET,
    LANG_UNKNOWN
} LangType;

// 命令类型
typedef enum {
    CMD_INSTALL,
    CMD_LS_REMOTE,
    CMD_LIST,
    CMD_USE,
    CMD_UPGRADE,
    CMD_UNINSTALL,
    CMD_UNREGISTER,
    CMD_UNKNOWN
} CmdType;

// 下载进度回调函数类型
typedef void (*DownloadProgressCallback)(DWORD downloaded, DWORD total, double speed);

// ====================== 控制台UI函数 ======================
// 设置控制台颜色
void SetConsoleColor(int color);
// 打印进度条
void PrintProgressBar(DWORD downloaded, DWORD total, double speed);
// 打印带颜色的日志
void Log(const TCHAR* format, ...);
void LogSuccess(const TCHAR* format, ...);
void LogError(const TCHAR* format, ...);

// ====================== 权限处理函数 ======================
// 检查是否为管理员权限
BOOL IsAdmin();
// 提权重启程序
BOOL ElevateSelf();

// ====================== 下载函数 ======================
// 下载文件（带进度回调）
BOOL DownloadFile(const TCHAR* url, const TCHAR* savePath, DownloadProgressCallback callback);

// ====================== 解压函数 ======================
// 解压ZIP文件到指定目录
// 创建递归目录（新增声明）
BOOL CreateDirRecursive(const TCHAR* dir);
// 解压ZIP文件到指定目录
BOOL UnzipFile(const TCHAR* zipPath, const TCHAR* destDir);

// ====================== 环境变量函数 ======================
// 获取系统PATH环境变量
BOOL GetSystemPATH(TCHAR* pathBuf, DWORD bufSize);
// 添加路径到系统PATH
BOOL AddToSystemPATH(const TCHAR* path);
// 刷新系统环境变量（立即生效）
void RefreshEnvironment();

// ====================== 版本管理函数 ======================
// 解析语言类型
LangType ParseLangType(const TCHAR* langStr);
// 解析命令类型
CmdType ParseCmdType(const TCHAR* cmdStr);
// 创建软链接
BOOL CreateSymLink(const TCHAR* target, const TCHAR* linkPath);
// 获取语言安装目录
void GetLangInstallDir(LangType lang, const TCHAR* version, TCHAR* dirBuf);
// 获取语言当前版本软链接目录
void GetLangCurrentDir(LangType lang, TCHAR* dirBuf);
// 列出本机已安装版本
void ListInstalledVersions();
// 切换语言版本
BOOL SwitchLangVersion(LangType lang, const TCHAR* version);
// 卸载语言
BOOL UninstallLang(LangType lang);

// ====================== 命令处理函数 ======================
// 处理install命令
BOOL HandleInstall(LangType lang, const TCHAR* version);
// 处理ls-remote命令
BOOL HandleLsRemote(LangType lang);
// 处理use命令
BOOL HandleUse(LangType lang, const TCHAR* version);
// 处理unregister命令（卸载自身）
BOOL HandleUnregister();
