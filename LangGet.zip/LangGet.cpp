﻿#include "LangGet.h"

// 打印帮助信息
void PrintHelp() {
    Log(_T("LangGet - 极简编程语言版本管理工具 (Win64)"));
    Log(_T("用法:"));
    Log(_T("  langget install <lang>[@version]    安装指定语言版本（默认最新）"));
    Log(_T("  langget ls-remote <lang>           查看可安装版本"));
    Log(_T("  langget list                       查看本机已装版本"));
    Log(_T("  langget use <lang>@version         切换全局版本"));
    Log(_T("  langget upgrade <lang>             升级到最新版本"));
    Log(_T("  langget uninstall <lang>           卸载指定语言"));
    Log(_T("  langget --unregister               卸载LangGet自身"));
    Log(_T("支持语言: python, nodejs, jdk, go, rust, mingw, dotnet"));
}

int _tmain(int argc, TCHAR* argv[]) {
    // 设置控制台编码为UTF-8（避免中文乱码）
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);

    // 无参数时打印帮助
    if (argc < 2) {
        PrintHelp();
        return 0;
    }

    // 解析命令
    CmdType cmd = ParseCmdType(argv[1]);
    switch (cmd) {
    case CMD_INSTALL: {
        if (argc < 3) {
            LogError(_T("缺少参数: langget install <lang>[@version]"));
            return 1;
        }

        // 解析语言和版本（如python@3.12.4）
        TCHAR langStr[MAX_PATH] = { 0 };
        TCHAR version[MAX_PATH] = { 0 };
        TCHAR* pAt = _tcschr(argv[2], _T('@'));
        if (pAt) {
            _tcsncpy(langStr, argv[2], pAt - argv[2]);
            _tcscpy(version, pAt + 1);
        }
        else {
            _tcscpy(langStr, argv[2]);
            _tcscpy(version, _T("latest")); // 默认最新版
        }

        LangType lang = ParseLangType(langStr);
        HandleInstall(lang, version);
        break;
    }

    case CMD_LS_REMOTE: {
        if (argc < 3) {
            LogError(_T("缺少参数: langget ls-remote <lang>"));
            return 1;
        }
        LangType lang = ParseLangType(argv[2]);
        HandleLsRemote(lang);
        break;
    }

    case CMD_LIST: {
        ListInstalledVersions();
        break;
    }

    case CMD_USE: {
        if (argc < 3) {
            LogError(_T("缺少参数: langget use <lang>@version"));
            return 1;
        }

        TCHAR langStr[MAX_PATH] = { 0 };
        TCHAR version[MAX_PATH] = { 0 };
        TCHAR* pAt = _tcschr(argv[2], _T('@'));
        if (!pAt) {
            LogError(_T("参数格式错误: 需指定版本，如 python@3.12"));
            return 1;
        }

        _tcsncpy(langStr, argv[2], pAt - argv[2]);
        _tcscpy(version, pAt + 1);
        LangType lang = ParseLangType(langStr);
        HandleUse(lang, version);
        break;
    }

    case CMD_UPGRADE: {
        if (argc < 3) {
            LogError(_T("缺少参数: langget upgrade <lang>"));
            return 1;
        }
        LangType lang = ParseLangType(argv[2]);
        Log(_T("升级 %s 到最新版本（暂未实现）"), argv[2]);
        break;
    }

    case CMD_UNINSTALL: {
        if (argc < 3) {
            LogError(_T("缺少参数: langget uninstall <lang>"));
            return 1;
        }
        LangType lang = ParseLangType(argv[2]);
        UninstallLang(lang);
        break;
    }

    case CMD_UNREGISTER: {
        HandleUnregister();
        break;
    }

    default: {
        LogError(_T("未知命令: %s"), argv[1]);
        PrintHelp();
        return 1;
    }
    }

    return 0;
}