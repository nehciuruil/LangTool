﻿#include "LangGet.h"

// 检查是否为管理员权限
BOOL IsAdmin() {
    BOOL bIsAdmin = FALSE;
    PSID pAdminSID = NULL;
    SID_IDENTIFIER_AUTHORITY NtAuthority = SECURITY_NT_AUTHORITY;

    // 创建管理员组SID
    if (AllocateAndInitializeSid(
        &NtAuthority,
        2,
        SECURITY_BUILTIN_DOMAIN_RID,
        DOMAIN_ALIAS_RID_ADMINS,
        0, 0, 0, 0, 0, 0,
        &pAdminSID)) {
        // 检查当前进程是否在管理员组
        CheckTokenMembership(NULL, pAdminSID, &bIsAdmin);
        FreeSid(pAdminSID);
    }
    return bIsAdmin;
}

// 提权自身（以管理员身份重启）
BOOL ElevateSelf() {
    // ========== 所有变量移到goto前声明 ==========
    TCHAR szPath[MAX_PATH] = { 0 };
    TCHAR szHost[256] = { 0 }; // 兼容Download逻辑，提前声明
    URL_COMPONENTS urlComp = { 0 }; // 提前声明
    SHELLEXECUTEINFO sei = { 0 };

    // 获取自身路径
    if (!GetModuleFileName(NULL, szPath, MAX_PATH)) {
        LogError(_T("获取程序路径失败: %d"), GetLastError());
        return FALSE;
    }

    // 构造提权启动参数
    sei.cbSize = sizeof(SHELLEXECUTEINFO);
    sei.fMask = SEE_MASK_NOCLOSEPROCESS;
    sei.hwnd = NULL;
    sei.lpVerb = _T("runas"); // 管理员权限
    sei.lpFile = szPath;
    sei.lpParameters = GetCommandLine(); // 传递原参数
    sei.lpDirectory = NULL;
    sei.nShow = SW_SHOWNORMAL;

    // 启动提权进程
    if (!ShellExecuteEx(&sei)) {
        DWORD err = GetLastError();
        // 用户取消UAC弹窗
        if (err == ERROR_CANCELLED) {
            LogError(_T("提权被取消"));
            return FALSE;
        }
        LogError(_T("提权失败: %d"), err);
        goto Cleanup; // 变量已提前声明，无错误
    }

    // 等待提权进程退出
    WaitForSingleObject(sei.hProcess, INFINITE);
    CloseHandle(sei.hProcess);
    return TRUE;

Cleanup:
    CloseHandle(sei.hProcess); // 安全清理
    return FALSE;
}

// 获取系统PATH环境变量
BOOL GetSystemPATH(TCHAR* szPATH, DWORD dwSize) {
    HKEY hKey = NULL;
    DWORD dwType = REG_EXPAND_SZ;
    DWORD dwDataSize = dwSize * sizeof(TCHAR);

    // 打开系统环境变量注册表项
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
        _T("SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment"),
        0, KEY_READ, &hKey) != ERROR_SUCCESS) {
        LogError(_T("打开注册表失败: %d"), GetLastError());
        goto Cleanup;
    }

    // 读取PATH值
    if (RegQueryValueEx(hKey, _T("PATH"), NULL, &dwType, (LPBYTE)szPATH, &dwDataSize) != ERROR_SUCCESS) {
        LogError(_T("读取PATH失败: %d"), GetLastError());
        goto Cleanup;
    }

    RegCloseKey(hKey);
    return TRUE;

Cleanup:
    if (hKey != NULL) RegCloseKey(hKey);
    return FALSE;
}

// 添加目录到系统PATH
BOOL AddToSystemPATH(const TCHAR* dir) {
    if (!IsAdmin()) {
        LogError(_T("修改系统PATH需要管理员权限"));
        return ElevateSelf();
    }

    TCHAR szOldPATH[MAX_PATH_LEN] = { 0 };
    TCHAR szNewPATH[MAX_PATH_LEN] = { 0 };
    HKEY hKey = NULL;
    DWORD dwType = REG_EXPAND_SZ;
    DWORD dwDataSize = MAX_PATH_LEN * sizeof(TCHAR);

    // 读取原有PATH
    if (!GetSystemPATH(szOldPATH, MAX_PATH_LEN)) {
        return FALSE;
    }

    // 检查是否已存在
    if (_tcsstr(szOldPATH, dir) != NULL) {
        Log(_T("目录已在PATH中: %s"), dir);
        return TRUE;
    }

    // 拼接新PATH
    _stprintf(szNewPATH, _T("%s;%s"), szOldPATH, dir);

    // 打开注册表（可写）
    if (RegOpenKeyEx(HKEY_LOCAL_MACHINE,
        _T("SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment"),
        0, KEY_WRITE, &hKey) != ERROR_SUCCESS) {
        LogError(_T("打开注册表失败: %d"), GetLastError());
        goto Cleanup;
    }

    // 写入新PATH
    if (RegSetValueEx(hKey, _T("PATH"), 0, dwType, (LPBYTE)szNewPATH, dwDataSize) != ERROR_SUCCESS) {
        LogError(_T("写入PATH失败: %d"), GetLastError());
        goto Cleanup;
    }

    // 通知系统更新环境变量
    SendMessageTimeout(HWND_BROADCAST, WM_SETTINGCHANGE, 0, (LPARAM)_T("Environment"), SMTO_ABORTIFHUNG, 5000, NULL);

    LogSuccess(_T("已添加 %s 到系统PATH"), dir);
    RegCloseKey(hKey);
    return TRUE;

Cleanup:
    if (hKey != NULL) RegCloseKey(hKey);
    return FALSE;
}