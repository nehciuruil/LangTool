﻿#include "LangGet.h"

// 全局进度回调相关变量
static DownloadProgressCallback g_ProgressCallback = NULL;
static DWORD g_TotalSize = 0;
static DWORD g_LastDownloaded = 0;
static DWORD g_StartTime = 0;

// WinHTTP下载回调函数
void CALLBACK DownloadCallback(HINTERNET hInternet, DWORD_PTR dwContext, DWORD dwInternetStatus, LPVOID lpvStatusInformation, DWORD dwStatusInformationLength) {
    UNREFERENCED_PARAMETER(hInternet);
    UNREFERENCED_PARAMETER(dwContext);

    if (dwInternetStatus == INTERNET_STATUS_CONTENT_LENGTH_RECEIVED) {
        g_TotalSize = *((DWORD*)lpvStatusInformation);
    }
    else if (dwInternetStatus == INTERNET_STATUS_DATA_RECEIVED) {
        DWORD downloaded = *((DWORD*)lpvStatusInformation);
        DWORD currentTime = GetTickCount();
        double elapsed = (currentTime - g_StartTime) / 1000.0;
        double speed = (downloaded - g_LastDownloaded) / elapsed;
        g_LastDownloaded = downloaded;

        if (g_ProgressCallback != NULL) {
            g_ProgressCallback(downloaded, g_TotalSize, speed);
        }
    }
}

// 下载文件（核心修复：err变量移到goto前）
BOOL DownloadFile(const TCHAR* url, const TCHAR* savePath, DownloadProgressCallback callback) {
    // ========== 所有变量移到goto前声明 ==========
    HINTERNET hSession = NULL;
    HINTERNET hConnect = NULL;
    HINTERNET hRequest = NULL;
    FILE* fp = NULL;
    BYTE buffer[BUFFER_SIZE] = { 0 };
    DWORD bytesRead = 0;
    DWORD bytesWritten = 0;
    BOOL bSuccess = FALSE;
    TCHAR szHost[256] = { 0 };
    TCHAR szPath[1024] = { 0 };
    URL_COMPONENTS urlComp = { 0 };
    errno_t err = 0; // 关键修复：err移到goto前初始化

    // 初始化进度变量
    g_ProgressCallback = callback;
    g_TotalSize = 0;
    g_LastDownloaded = 0;
    g_StartTime = GetTickCount();

    // 创建WinHTTP会话
    hSession = WinHttpOpen(
        _T("LangGet/1.0"),
        WINHTTP_ACCESS_TYPE_NO_PROXY,
        WINHTTP_NO_PROXY_NAME,
        WINHTTP_NO_PROXY_BYPASS,
        0);
    if (hSession == NULL) {
        LogError(_T("创建WinHTTP会话失败: %d"), GetLastError());
        goto Cleanup;
    }

    // 解析URL
    urlComp.dwStructSize = sizeof(URL_COMPONENTS);
    urlComp.lpszHostName = szHost;
    urlComp.dwHostNameLength = _countof(szHost);
    urlComp.lpszUrlPath = szPath;
    urlComp.dwUrlPathLength = _countof(szPath);

    if (!WinHttpCrackUrl(url, (DWORD)_tcslen(url), 0, &urlComp)) {
        LogError(_T("解析URL失败: %d"), GetLastError());
        goto Cleanup;
    }

    // 连接服务器
    hConnect = WinHttpConnect(
        hSession,
        szHost,
        urlComp.nPort,
        0);
    if (hConnect == NULL) {
        LogError(_T("连接服务器失败: %d"), GetLastError());
        goto Cleanup;
    }

    // 创建GET请求
    hRequest = WinHttpOpenRequest(
        hConnect,
        _T("GET"),
        szPath,
        NULL,
        WINHTTP_NO_REFERER,
        WINHTTP_DEFAULT_ACCEPT_TYPES,
        (urlComp.nScheme == INTERNET_SCHEME_HTTPS) ? WINHTTP_FLAG_SECURE : 0);
    if (hRequest == NULL) {
        LogError(_T("创建HTTP请求失败: %d"), GetLastError());
        goto Cleanup;
    }

    // 设置回调
    WinHttpSetStatusCallback(
        hRequest,
        DownloadCallback,
        WINHTTP_CALLBACK_FLAG_STATUS_ALL_COMPLETIONS,
        NULL);

    // 发送请求
    if (!WinHttpSendRequest(hRequest, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0)) {
        LogError(_T("发送HTTP请求失败: %d"), GetLastError());
        goto Cleanup;
    }

    // 接收响应
    if (!WinHttpReceiveResponse(hRequest, NULL)) {
        LogError(_T("接收HTTP响应失败: %d"), GetLastError());
        goto Cleanup;
    }

    // 打开保存文件（err已提前声明）
    err = _tfopen_s(&fp, savePath, _T("wb"));
    if (err != 0 || fp == NULL) {
        LogError(_T("创建保存文件失败: %s (错误码: %d)"), savePath, err);
        goto Cleanup;
    }

    // 循环读写
    while (WinHttpReadData(hRequest, buffer, BUFFER_SIZE, &bytesRead) && bytesRead > 0) {
        fwrite(buffer, 1, bytesRead, fp);
        bytesWritten += bytesRead;
    }

    // 验证完整性
    if (g_TotalSize > 0 && bytesWritten != g_TotalSize) {
        LogError(_T("下载不完整: 已下载 %d 字节，总大小 %d 字节"), bytesWritten, g_TotalSize);
        goto Cleanup;
    }

    bSuccess = TRUE;
    LogSuccess(_T("下载完成"));

Cleanup:
    if (fp != NULL) fclose(fp);
    if (hRequest != NULL) WinHttpCloseHandle(hRequest);
    if (hConnect != NULL) WinHttpCloseHandle(hConnect);
    if (hSession != NULL) WinHttpCloseHandle(hSession);
    return bSuccess;
}